
//获取应用实例
Page({
  onTap:function(){
    // wx.navigateTo({
    //   url:"../posts/post"
    // }); 可返回

    //不可返回
    wx.switchTab({
      url: "../posts/post"
    });
    
  }

  
})